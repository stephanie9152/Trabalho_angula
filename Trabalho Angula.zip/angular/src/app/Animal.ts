export interface Animal {
    id: number;
    nome: string;
    telefone: string;
    email: string;
    empresa: string;
}